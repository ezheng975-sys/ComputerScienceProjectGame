extends Camera2D



func _ready() -> void:
	pass # Replace with function body.
	# signal for when to be enabled

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
	#global position = player position
