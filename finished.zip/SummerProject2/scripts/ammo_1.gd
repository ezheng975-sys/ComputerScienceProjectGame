extends Label

func _ready() -> void:
	text = "532452"
	
func _physics_process(delta: float) -> void:
	text = str($"../../Map/Player 1".current_ammo)
	
	if $"../../Map/Player 1".current_ammo < 4:
		add_theme_color_override("font_color", Color.RED)
	else: 
		add_theme_color_override("font_color", Color.WHITE)
		
	if GameManager.p1_rounds_won == 7 or GameManager.p2_rounds_won == 7:
		text = ""
