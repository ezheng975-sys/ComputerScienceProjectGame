extends CharacterBody2D
class_name Players

@export var player_id: int 
@export var death_tp: Marker2D
@onready var gun: Node2D = $Gun
var health: int = 100
var current_ammo: int = 0

func _ready() -> void:
	GameManager.round_started.connect(_on_round_start)
	$HealthComponent.damage_taken.connect(_on_damage_taken)
	if player_id:
		$AnimatedSprite2D.flip_h = bool(player_id - 1)
	

func _physics_process(delta: float) -> void:
	health = $HealthComponent.current_health
	current_ammo = gun.current_ammo
	
func _on_round_start():
	if player_id:
		$AnimatedSprite2D.flip_h = bool(player_id - 1)
	
func _on_damage_taken(damage):
	#$"../AnimatedSprite2D".modulate = Color(1,0,0)
	#await get_tree().create_timer(0.1).timeout
	#$"../AnimatedSprite2D".modulate = Color(1,1,1)
	pass

	


	
