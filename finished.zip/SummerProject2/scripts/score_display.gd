extends Label
var i = 0

func _ready() -> void:
	pass



func _process(delta: float) -> void:
	update_text()

func update_text():
	text = str(GameManager.p1_rounds_won)+ " - " + str(GameManager.p2_rounds_won)
	if GameManager.p1_rounds_won == 7:
		while i < 1:
			position.y += 110
			position.x -= 140
			add_theme_font_size_override("font_size", 70)
			add_theme_color_override("font_color", Color.BLUE)
			i += 1
		text = "BLUE Wins!"
			
		
	if GameManager.p2_rounds_won == 7:
		while i < 1:
			position.y += 110
			position.x -= 140
			add_theme_font_size_override("font_size", 70)
			add_theme_color_override("font_color", Color.RED)
			i += 1
		text = "RED Wins!"
