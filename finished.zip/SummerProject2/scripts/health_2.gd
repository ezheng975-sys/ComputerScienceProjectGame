extends Label

@export var player: Node2D

func _ready() -> void:
	pass



func _process(delta: float) -> void:
	update_text()

func update_text():
	text = "HP: " + str(player.health)
	if GameManager.p1_rounds_won == 7 or GameManager.p2_rounds_won == 7:
		text = ""
	if GameManager.dead_player == 2: 
		text = "0"
