extends Node2D
class_name Gun

var bullet_scene = preload("res://scenes/bullet.tscn")
@onready var muzzle: Marker2D = $MuzzlePoint
@onready var parent: CharacterBody2D = get_parent()
@onready var starting_x: float = position.x
var bullet_dir = Vector2.RIGHT
@export var max_ammo: int = 10
var current_ammo = max_ammo
var is_spinning = false
var reloading = false




func _ready() -> void:
	GameManager.round_started.connect(_on_round_start)

func _physics_process(_delta: float) -> void:
	
	var player_sprite = $"../AnimatedSprite2D" 
	if player_sprite:
		if player_sprite.flip_h:
			
			bullet_dir = Vector2.LEFT
			position.x = -starting_x
			scale.x = -1
		else:
			bullet_dir = Vector2.RIGHT
			position.x = starting_x
			scale.x = 1
	
	
	#direction of bullet
	if Input.is_action_just_pressed("p" + str(parent.player_id) + "_shoot"):
		
		if $"../AnimatedSprite2D".flip_h:
			bullet_dir = Vector2.LEFT

		else:
			bullet_dir = Vector2.RIGHT
			
		if reloading == false:
			shoot()
		
	if Input.is_action_just_pressed("p" + str(parent.player_id) + "_reload") and reloading == false and current_ammo < max_ammo: # reload
		reloading = true
		GameManager.ammo_changed.emit(current_ammo)
		reload(1)



			
	

	



func shoot():
	
	#new bullet
	
	if current_ammo > 0:
		current_ammo -= 1
		var new_bullet = bullet_scene.instantiate()
		get_tree().current_scene.add_child(new_bullet)
		new_bullet.global_position = $MuzzlePoint.global_position
		new_bullet.direction = bullet_dir
		GameManager.ammo_changed.emit(current_ammo)
		
	else: 
		return
		
func reload(duration: float):
	var tween: Tween = create_tween()
	

	tween.tween_property($AnimatedSprite2D, "rotation", $AnimatedSprite2D.rotation + TAU, duration).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	await get_tree().create_timer(duration).timeout
	current_ammo = max_ammo
	reloading = false
	
func _on_round_start():
	current_ammo = max_ammo

	
