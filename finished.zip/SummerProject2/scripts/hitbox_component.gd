extends Area2D
class_name HitboxComponent

@export var damage: int = 5 # damage
var parent: Area2D = get_parent()


func _physics_process(delta: float) -> void:
	pass
	# remember to add everything to change the damage of the attack with different weapons using signals


func _on_area_entered(area: Area2D) -> void: # when entering hurtbox
	#  animations here later
	queue_free()
