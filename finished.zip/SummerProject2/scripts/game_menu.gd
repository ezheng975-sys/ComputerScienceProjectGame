extends Control


func _ready() -> void:
	resume()
	$"pause button".global_position = $"Pause menu background/Marker2D2".global_position
	$"Pause menu background".visible = false
	$"Resume button".visible = false
	$"Main menu button".visible = false
	$"Quit button".visible = false

func _on_button_pressed() -> void: #pause button
	if $"pause button".icon == preload("res://assets/images/settings (1).png"):
		pause()
	elif $"pause button".icon == preload("res://assets/images/x-button.png"):
		resume()


	#get_tree().change_scene_to_file("res://scenes/start_menu.tscn") remember to add this to the main menu button


func _on_resume_button_pressed() -> void:
	resume()
	

func pause():
	$"pause button".global_position = $"Pause menu background/Marker2D".global_position
	$"pause button".icon = preload("res://assets/images/x-button.png")
	get_tree().paused = true
	$"Pause menu background".visible = true
	$"Resume button".visible = true
	$"Main menu button".visible = true
	$"Quit button".visible = true

func resume():
	$"Pause menu background".visible = false
	$"Resume button".visible = false
	$"Main menu button".visible = false
	$"Quit button".visible = false
	$"pause button".icon = preload("res://assets/images/settings (1).png")
	get_tree().paused = false
	$"pause button".global_position = $"Pause menu background/Marker2D2".global_position
	$"Quit button".text = "Quit"


func _on_main_menu_button_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/start_menu.tscn")


func _on_quit_button_pressed() -> void:
	if $"Quit button".text == "Quit":
		$"Quit button".text = "Are you sure?"
	elif $"Quit button".text == "Are you sure?":
		if OS.has_feature("web"):
			JavaScriptBridge.eval("window.close();")
		else:
			get_tree().quit()
